// Portal de Vendas B2B (versão com painel admin e usuário Higiene Leste)
// Tecnologias: React + Tailwind (interface), simulação de dados locais

import { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Image from 'next/image';

const mockProducts = [
  { id: 1, name: "Álcool 70% 1L", price: 9.9, image: "/product1.png" },
  { id: 2, name: "Papel Toalha Interfolha", price: 48.5, image: "/product2.png" },
  { id: 3, name: "Detergente Neutro 5L", price: 23.9, image: "/product3.png" },
  { id: 4, name: "Sabonete Líquido 800ml", price: 14.5, image: "/product4.png" },
  { id: 5, name: "Luvas de Vinil c/100", price: 29.9, image: "/product5.png" },
  { id: 6, name: "Máscara Descartável 50un", price: 19.9, image: "/product6.png" },
  { id: 7, name: "Saco de Lixo 100L Preto c/100", price: 37.9, image: "/product7.png" },
  { id: 8, name: "Desinfetante Floral 5L", price: 16.8, image: "/product8.png" },
  { id: 9, name: "Rodo Alumínio 40cm", price: 21.5, image: "/product9.png" },
  { id: 10, name: "Pano de Chão Branco kg", price: 9.4, image: "/product10.png" },
];

const mockUsers = {
  "higiene_leste": { password: "1234", name: "Higiene Leste", isAdmin: false },
  "admin": { password: "admin123", name: "Administrador", isAdmin: true },
};

export default function PortalVendasB2B() {
  const [user, setUser] = useState(null);
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [cart, setCart] = useState([]);
  const [products, setProducts] = useState(mockProducts);
  const [newProduct, setNewProduct] = useState({ name: '', price: '', image: '' });

  const handleLogin = () => {
    if (mockUsers[login] && mockUsers[login].password === password) {
      setUser({ username: login, ...mockUsers[login] });
    } else {
      alert("Login inválido");
    }
  };

  const addToCart = (product) => {
    setCart((prev) => [...prev, product]);
  };

  const finalizeOrder = () => {
    alert(`Pedido enviado com ${cart.length} itens.`);
    setCart([]);
  };

  const handleAddProduct = () => {
    if (!newProduct.name || !newProduct.price || !newProduct.image) return alert("Preencha todos os campos.");
    const newItem = {
      id: products.length + 1,
      name: newProduct.name,
      price: parseFloat(newProduct.price),
      image: newProduct.image,
    };
    setProducts([...products, newItem]);
    setNewProduct({ name: '', price: '', image: '' });
  };

  if (!user) {
    return (
      <div className="max-w-sm mx-auto mt-20 p-4 border rounded-xl shadow text-center">
        <Image src="/logo.png" alt="Logo Higiene Leste" width={200} height={200} className="mx-auto mb-4" />
        <h2 className="text-xl font-bold mb-4">Portal de Vendas</h2>
        <Input placeholder="Usuário" value={login} onChange={(e) => setLogin(e.target.value)} className="mb-2" />
        <Input type="password" placeholder="Senha" value={password} onChange={(e) => setPassword(e.target.value)} className="mb-4" />
        <Button onClick={handleLogin} className="w-full">Entrar</Button>
      </div>
    );
  }

  if (user.isAdmin) {
    return (
      <div className="max-w-3xl mx-auto mt-10 p-4">
        <h2 className="text-2xl font-semibold mb-4">Painel do Administrador</h2>
        <div className="mb-6">
          <h3 className="text-lg font-bold mb-2">Cadastrar Novo Produto</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
            <Input placeholder="Nome do produto" value={newProduct.name} onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })} />
            <Input placeholder="Preço" type="number" value={newProduct.price} onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })} />
            <Input placeholder="URL da imagem" value={newProduct.image} onChange={(e) => setNewProduct({ ...newProduct, image: e.target.value })} />
            <Button onClick={handleAddProduct}>Adicionar</Button>
          </div>
        </div>
        <h3 className="text-xl font-semibold mb-2">Produtos Atuais</h3>
        <ul className="list-disc ml-5">
          {products.map(p => (
            <li key={p.id}>{p.name} - R$ {p.price.toFixed(2)}</li>
          ))}
        </ul>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto mt-10 p-4">
      <h2 className="text-2xl font-semibold mb-4">Bem-vindo, {user.name}</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {products.map((product) => (
          <Card key={product.id}>
            <CardContent className="p-4">
              {product.image && <Image src={product.image} alt={product.name} width={150} height={150} className="mx-auto mb-2" />}
              <h3 className="text-lg font-bold text-center">{product.name}</h3>
              <p className="text-sm mb-2 text-center">R$ {product.price.toFixed(2)}</p>
              <Button className="w-full" onClick={() => addToCart(product)}>Adicionar ao pedido</Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-10">
        <h3 className="text-xl font-semibold mb-2">Carrinho ({cart.length})</h3>
        {cart.length === 0 ? <p>Nenhum item no carrinho.</p> : (
          <>
            <ul className="mb-4 list-disc ml-5">
              {cart.map((item, index) => (
                <li key={index}>{item.name} - R$ {item.price.toFixed(2)}</li>
              ))}
            </ul>
            <Button onClick={finalizeOrder}>Finalizar Pedido</Button>
          </>
        )}
      </div>
    </div>
  );
}
