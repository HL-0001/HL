export function Button({ children, onClick, className }) {
  return <button onClick={onClick} className={`bg-black text-white p-2 rounded ${className}`}>{children}</button>;
}